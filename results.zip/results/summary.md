| model                   | polarity   | condition         |   n |   parse_rate |   accuracy |   follow_rate |   flip_rate |   conflict_rate |   own_desc_acc |
|:------------------------|:-----------|:------------------|----:|-------------:|-----------:|--------------:|------------:|----------------:|---------------:|
| gemini/gemini-3.7-flash | contradict | Chart only        |   2 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| gemini/gemini-3.7-flash | contradict | Caption           |   2 |        1.000 |      1.000 |         0.000 |       0.000 |           0.000 |        nan     |
| gemini/gemini-3.7-flash | contradict | User, bare        |   2 |        1.000 |      1.000 |         0.000 |       0.000 |           0.000 |        nan     |
| gemini/gemini-3.7-flash | contradict | Scripted own turn |   2 |        1.000 |      1.000 |         0.000 |       0.000 |           0.000 |        nan     |
| ollama/gemma3:4b        | consistent | Chart only        | 200 |        1.000 |      0.845 |       nan     |     nan     |         nan     |        nan     |
| ollama/gemma3:4b        | consistent | Caption           | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/gemma3:4b        | consistent | User, bare        | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/gemma3:4b        | consistent | User, opinion     | 200 |        1.000 |      0.945 |       nan     |     nan     |         nan     |        nan     |
| ollama/gemma3:4b        | consistent | User, expert      | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/gemma3:4b        | consistent | Scripted own turn | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/gemma3:4b        | consistent | Self-caption      | 200 |        1.000 |      0.970 |       nan     |     nan     |         nan     |          0.834 |
| ollama/gemma3:4b        | contradict | Chart only        | 200 |        1.000 |      0.845 |       nan     |     nan     |         nan     |        nan     |
| ollama/gemma3:4b        | contradict | Caption           | 200 |        1.000 |      0.410 |         0.590 |       0.515 |           0.000 |        nan     |
| ollama/gemma3:4b        | contradict | User, bare        | 200 |        1.000 |      0.440 |         0.560 |       0.479 |           0.000 |        nan     |
| ollama/gemma3:4b        | contradict | User, opinion     | 200 |        1.000 |      0.530 |         0.470 |       0.373 |           0.000 |        nan     |
| ollama/gemma3:4b        | contradict | User, expert      | 200 |        1.000 |      0.360 |         0.640 |       0.574 |           0.000 |        nan     |
| ollama/gemma3:4b        | contradict | Scripted own turn | 200 |        1.000 |      0.375 |         0.625 |       0.556 |           0.000 |        nan     |
| ollama/gemma3:4b        | contradict | Self-caption      | 200 |        1.000 |      0.585 |         0.415 |       0.308 |           0.000 |          0.834 |
| ollama/qwen2.5vl:3b     | consistent | Chart only        | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:3b     | consistent | Caption           | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:3b     | consistent | User, bare        | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:3b     | consistent | User, opinion     | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:3b     | consistent | User, expert      | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:3b     | consistent | Scripted own turn | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:3b     | consistent | Self-caption      | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |          1.000 |
| ollama/qwen2.5vl:3b     | contradict | Chart only        | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:3b     | contradict | Caption           | 200 |        1.000 |      0.990 |         0.010 |       0.010 |           0.000 |        nan     |
| ollama/qwen2.5vl:3b     | contradict | User, bare        | 200 |        1.000 |      0.925 |         0.075 |       0.075 |           0.000 |        nan     |
| ollama/qwen2.5vl:3b     | contradict | User, opinion     | 200 |        1.000 |      0.960 |         0.040 |       0.040 |           0.000 |        nan     |
| ollama/qwen2.5vl:3b     | contradict | User, expert      | 200 |        1.000 |      0.980 |         0.020 |       0.020 |           0.000 |        nan     |
| ollama/qwen2.5vl:3b     | contradict | Scripted own turn | 200 |        1.000 |      0.770 |         0.230 |       0.230 |           0.000 |        nan     |
| ollama/qwen2.5vl:3b     | contradict | Self-caption      | 200 |        1.000 |      0.680 |         0.320 |       0.320 |           0.000 |          1.000 |
| ollama/qwen2.5vl:7b     | consistent | Chart only        | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:7b     | consistent | Caption           | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:7b     | consistent | User, bare        | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:7b     | consistent | User, opinion     | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:7b     | consistent | User, expert      | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:7b     | consistent | Scripted own turn | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:7b     | consistent | Self-caption      | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |          1.000 |
| ollama/qwen2.5vl:7b     | contradict | Chart only        | 200 |        1.000 |      1.000 |       nan     |     nan     |         nan     |        nan     |
| ollama/qwen2.5vl:7b     | contradict | Caption           | 200 |        1.000 |      1.000 |         0.000 |       0.000 |           0.000 |        nan     |
| ollama/qwen2.5vl:7b     | contradict | User, bare        | 200 |        1.000 |      1.000 |         0.000 |       0.000 |           0.000 |        nan     |
| ollama/qwen2.5vl:7b     | contradict | User, opinion     | 200 |        1.000 |      1.000 |         0.000 |       0.000 |           0.000 |        nan     |
| ollama/qwen2.5vl:7b     | contradict | User, expert      | 200 |        1.000 |      1.000 |         0.000 |       0.000 |           0.000 |        nan     |
| ollama/qwen2.5vl:7b     | contradict | Scripted own turn | 200 |        1.000 |      0.900 |         0.100 |       0.100 |           0.028 |        nan     |
| ollama/qwen2.5vl:7b     | contradict | Self-caption      | 200 |        1.000 |      1.000 |         0.000 |       0.000 |           0.005 |          1.000 |
